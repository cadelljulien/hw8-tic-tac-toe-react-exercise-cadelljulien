# HW 8
## COT4808 - Full Stack Web Development
### By Cadell Julien - Z23505110
#### Due Mar 26, 2023

[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=10599101&assignment_repo_type=AssignmentRepo)

![ezgif com-optimize](https://user-images.githubusercontent.com/123437478/227815996-10390788-6e6b-4c9d-b9f3-31519d4de992.gif)


### Summary
The making of the app using react was very interesting. Had a public folder which had a pick, json, and html file. Then we had a src or source folder which had a public fodler, several js and a style.css file. I'll briefly go over what was done within the App.js, since that's where most of the work was in. So continuing, App.js the represented part of the user interface. IT had parts for which one can use to render, manage, and update within the UI element of the application. The index.js bridges the component for App.js and the web browser. So starting off, we went to App.js and started building out the board thats reutnrs JSX elemetns, which bascilly added a sections for click on square. Then Made the board more interactive by making a fill section using onClick. Which then I moved on to the lifting state where it goes on the bases of turn. Finishing with declaring a winner with a time travel. With that  a show past move comes up.
